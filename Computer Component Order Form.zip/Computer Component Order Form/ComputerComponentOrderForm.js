function verifyOrderPlaced() {
    const firstNameField = document.forms["computer-component-order-form"]["firstName"].value;
    const lastNameField = document.forms["computer-component-order-form"]["lastName"].value;
    const contactNumberField = document.forms["computer-component-order-form"]["contactNumber"].value;

    const brandField = document.forms["computer-component-order-form"]["brand"].value;
    const gpuField = document.forms["computer-component-order-form"]["gpu"].value;
    const ramField = document.forms["computer-component-order-form"]["ram"].value;

    if (firstNameField == "" || lastNameField == "" || contactNumberField == "" || brandField == "" || gpuField == "" || ramField == "") {
        alert("Please ensure all fields are filled in");
    } else {
        alert('Order has been placed.')
    }
}
